module.exports = [
"[project]/.next-internal/server/app/products/new/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=_next-internal_server_app_products_new_page_actions_039b3c57.js.map