var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/products/my-products/route.js")
R.c("server/chunks/node_modules_fdd2987c._.js")
R.c("server/chunks/[root-of-the-server]__4d8fb002._.js")
R.c("server/chunks/_next-internal_server_app_api_products_my-products_route_actions_21b3790e.js")
R.m("[project]/node_modules/next/dist/esm/build/templates/app-route.js { INNER_APP_ROUTE => \"[project]/src/app/api/products/my-products/route.ts [app-route] (ecmascript)\" } [app-route] (ecmascript)")
module.exports=R.m("[project]/node_modules/next/dist/esm/build/templates/app-route.js { INNER_APP_ROUTE => \"[project]/src/app/api/products/my-products/route.ts [app-route] (ecmascript)\" } [app-route] (ecmascript)").exports
