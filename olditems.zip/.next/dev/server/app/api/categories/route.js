var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/categories/route.js")
R.c("server/chunks/node_modules_next_75d2a7c7._.js")
R.c("server/chunks/[root-of-the-server]__83b4ee32._.js")
R.c("server/chunks/_next-internal_server_app_api_categories_route_actions_9c21f11d.js")
R.m("[project]/node_modules/next/dist/esm/build/templates/app-route.js { INNER_APP_ROUTE => \"[project]/src/app/api/categories/route.ts [app-route] (ecmascript)\" } [app-route] (ecmascript)")
module.exports=R.m("[project]/node_modules/next/dist/esm/build/templates/app-route.js { INNER_APP_ROUTE => \"[project]/src/app/api/categories/route.ts [app-route] (ecmascript)\" } [app-route] (ecmascript)").exports
