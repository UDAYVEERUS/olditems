(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/[root-of-the-server]__f6202ce6._.css",
  "static/chunks/src_7a89a7a0._.js",
  "static/chunks/node_modules_0309b0c5._.js"
],
    source: "dynamic"
});
