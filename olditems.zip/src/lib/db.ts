// src/lib/db.ts
import mongoose from 'mongoose';

const MONGODB_URI = "mongodb+srv://udayveerus348568_db_user:pTy9NELY6b7uO9OZ@cluster0.vh3vby1.mongodb.net/olditems";
import dns from "dns";
dns.setDefaultResultOrder("ipv4first");
if (!MONGODB_URI) {
  throw new Error('❌ MONGODB_URI not found');
}

interface MongooseCache {
  conn: typeof mongoose | null;
  promise: Promise<typeof mongoose> | null;
}

let cached = (global as any).mongoose as MongooseCache;

if (!cached) {
  cached = (global as any).mongoose = { conn: null, promise: null };
}

async function dbConnect() {
  if (cached.conn) {
    return cached.conn;
  }

  if (!cached.promise) {
    cached.promise = mongoose.connect(MONGODB_URI).then((mongoose) => {
      console.log('✅ MongoDB connected:', mongoose.connection.db.databaseName);
      return mongoose;
    });
  }

  cached.conn = await cached.promise;
  return cached.conn;
}

export default dbConnect;
